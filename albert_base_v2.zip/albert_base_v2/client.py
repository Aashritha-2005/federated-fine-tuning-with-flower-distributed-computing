import flwr as fl
import torch
from transformers import AlbertTokenizer, AlbertForSequenceClassification
from sklearn.metrics import accuracy_score
from datasets import load_dataset
import sys

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Client: Using device: {DEVICE}")

# Load tokenizer and model
print("Client: Loading ALBERT tokenizer and model...")
tokenizer = AlbertTokenizer.from_pretrained("albert-base-v2")
model = AlbertForSequenceClassification.from_pretrained("albert-base-v2", num_labels=2)
model.to(DEVICE)
print("Client: Model loaded and moved to device")

# Load small subset of dataset
def load_data():
    print("Client: Loading IMDB dataset...")
    dataset = load_dataset("imdb", split="train[:2%]")
    dataset = dataset.train_test_split(test_size=0.3)
    print(f"Client: Loaded {len(dataset['train'])} training samples and {len(dataset['test'])} test samples")
    return dataset["train"], dataset["test"]

train_data, test_data = load_data()

# Tokenization
def tokenize(batch):
    return tokenizer(batch["text"], padding="max_length", truncation=True, max_length=128)

print("Client: Tokenizing datasets...")
train_data = train_data.map(tokenize, batched=True)
test_data = test_data.map(tokenize, batched=True)

train_data.set_format("torch", columns=["input_ids", "attention_mask", "label"])
test_data.set_format("torch", columns=["input_ids", "attention_mask", "label"])

# DataLoader
train_loader = torch.utils.data.DataLoader(train_data, batch_size=16, shuffle=True)
test_loader = torch.utils.data.DataLoader(test_data, batch_size=16)
print("Client: Data loaders created")

# Training function
def train(model, loader):
    print("Client: Starting training...")
    model.train()
    optimizer = torch.optim.Adam(model.parameters(), lr=5e-5)
    total_loss = 0
    num_batches = 0
    
    for epoch in range(1):
        print(f"Client: Training epoch {epoch + 1}")
        for batch_idx, batch in enumerate(loader):
            input_ids = batch["input_ids"].to(DEVICE)
            attention_mask = batch["attention_mask"].to(DEVICE)
            labels = batch["label"].to(DEVICE)

            outputs = model(input_ids, attention_mask=attention_mask, labels=labels)
            loss = outputs.loss
            total_loss += loss.item()
            num_batches += 1
            
            loss.backward()
            optimizer.step()
            optimizer.zero_grad()
            
            if batch_idx % 10 == 0:
                print(f"Client: Batch {batch_idx}/{len(loader)}, Loss: {loss.item():.4f}")
    
    avg_loss = total_loss / max(num_batches, 1)
    print(f"Client: Training completed. Average loss: {avg_loss:.4f}")
    return avg_loss

# Evaluation function
def test(model, loader):
    print("Client: Starting evaluation...")
    model.eval()
    predictions, labels = [], []
    total_loss = 0
    num_batches = 0
    
    with torch.no_grad():
        for batch_idx, batch in enumerate(loader):
            input_ids = batch["input_ids"].to(DEVICE)
            attention_mask = batch["attention_mask"].to(DEVICE)
            batch_labels = batch["label"]
            labels.extend(batch_labels.numpy())
            
            outputs = model(input_ids, attention_mask=attention_mask, labels=batch_labels.to(DEVICE))
            total_loss += outputs.loss.item()
            num_batches += 1
            
            preds = outputs.logits.argmax(dim=1).cpu().numpy()
            predictions.extend(preds)
            
            if batch_idx % 10 == 0:
                print(f"Client: Evaluation batch {batch_idx}/{len(loader)}")
    
    acc = accuracy_score(labels, predictions)
    avg_loss = total_loss / max(num_batches, 1)
    print(f"Client: Evaluation completed. Loss: {avg_loss:.4f}, Accuracy: {acc:.4f}")
    return avg_loss, acc

# Flower Client
class ALBERTClient(fl.client.NumPyClient):
    def get_parameters(self, config):
        print("Client: Getting model parameters...")
        parameters = [val.cpu().numpy() for _, val in model.state_dict().items()]
        print(f"Client: Extracted {len(parameters)} parameter arrays")
        return parameters

    def set_parameters(self, parameters):
        print("Client: Setting model parameters...")
        try:
            params_dict = zip(model.state_dict().keys(), parameters)
            state_dict = {k: torch.tensor(v) for k, v in params_dict}
            model.load_state_dict(state_dict, strict=True)
            print(f"Client: Successfully set {len(parameters)} parameter arrays")
        except Exception as e:
            print(f"Client: Error setting parameters: {e}")
            raise

    def fit(self, parameters, config):
        server_round = config.get('server_round', 'unknown')
        print(f"Client: === STARTING FIT ROUND {server_round} ===")
        
        try:
            self.set_parameters(parameters)
            avg_loss = train(model, train_loader)
            updated_parameters = self.get_parameters(config={})
            
            metrics = {"train_loss": avg_loss}
            print(f"Client: Fit round {server_round} completed successfully")
            print(f"Client: Returning {len(train_loader.dataset)} samples with metrics: {metrics}")
            
            return updated_parameters, len(train_loader.dataset), metrics
        except Exception as e:
            print(f"Client: Error during fit round {server_round}: {e}")
            raise

    def evaluate(self, parameters, config):
        server_round = config.get('server_round', 'unknown')
        print(f"Client: === STARTING EVALUATE ROUND {server_round} ===")
        
        try:
            self.set_parameters(parameters)
            avg_loss, acc = test(model, test_loader)
            
            metrics = {"eval_accuracy": float(acc)}
            print(f"Client: Evaluate round {server_round} completed successfully")
            print(f"Client: Returning loss: {avg_loss:.4f}, samples: {len(test_loader.dataset)}, metrics: {metrics}")
            
            return float(avg_loss), len(test_loader.dataset), metrics
        except Exception as e:
            print(f"Client: Error during evaluate round {server_round}: {e}")
            raise

def main():
    print("Starting Flower Federated Learning Client...")
    print("=" * 60)
    
    # Server address
    default_server = "192.168.33.72:8081" #Replace with your server IP address
    
    # Get server address from command line or use default
    if len(sys.argv) > 1:
        server_address = sys.argv[1]
    else:
        user_input = input(f"Enter server address (press Enter for {default_server}): ").strip()
        server_address = user_input if user_input else default_server
    
    # Ensure port is included
    if ":" not in server_address:
        server_address = f"{server_address}:8081"
    
    print(f"Client: Connecting to server at: {server_address}")
    print("=" * 60)
    
    try:
        print("Client: Creating client instance...")
        client = ALBERTClient()
        print("Client: Client instance created successfully")
        
        print("Client: Starting connection to server...")
        fl.client.start_numpy_client(
            server_address=server_address, 
            client=client
        )
        
        print("=" * 60)
        print("Client: Federated learning completed successfully!")
        
    except KeyboardInterrupt:
        print("\n" + "=" * 60)
        print("Client: Stopped by user.")
    except Exception as e:
        print("=" * 60)
        print(f"Client: Connection error: {e}")
        print("Client: Make sure the server is running and the IP address is correct.")
        print(f"Client: Expected server address: {default_server}")

if __name__ == "__main__":
    main()