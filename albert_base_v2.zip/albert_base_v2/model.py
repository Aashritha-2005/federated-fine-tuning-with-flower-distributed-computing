import flwr as fl
import torch
from typing import Dict, List, Tuple
from model import ModelManager, create_dummy_data
import sys

class FederatedClient(fl.client.NumPyClient):
    def _init_(self):
        self.model_manager = ModelManager()
        # Generate client-specific dummy data
        self.train_texts, self.train_labels = create_dummy_data(80)
        self.test_texts, self.test_labels = create_dummy_data(20)
        print(f"Client initialized with {len(self.train_texts)} training samples and {len(self.test_texts)} test samples")
    
    def get_parameters(self, config: Dict[str, str]) -> List[torch.Tensor]:
        """Extract model parameters."""
        print("Client: Getting model parameters...")
        return self.model_manager.get_parameters()
    
    def fit(self, parameters: List[torch.Tensor], config: Dict[str, str]) -> Tuple[List[torch.Tensor], int, Dict[str, float]]:
        """Train the model with provided parameters."""
        print(f"Client: Starting training round {config.get('server_round', 'unknown')}")
        
        # Set model parameters
        self.model_manager.set_parameters(parameters)
        
        # Train model
        epochs = int(config.get("local_epochs", 1))
        loss, accuracy = self.model_manager.train_model(self.train_texts, self.train_labels, epochs=epochs)
        
        print(f"Client: Training completed - Loss: {loss:.4f}, Accuracy: {accuracy:.4f}")
        
        # Return updated model parameters and training metrics
        return (
            self.model_manager.get_parameters(),
            len(self.train_texts),
            {"train_loss": loss, "train_accuracy": accuracy}
        )
    
    def evaluate(self, parameters: List[torch.Tensor], config: Dict[str, str]) -> Tuple[float, int, Dict[str, float]]:
        """Evaluate the model with provided parameters."""
        print(f"Client: Starting evaluation round {config.get('server_round', 'unknown')}")
        
        # Set model parameters
        self.model_manager.set_parameters(parameters)
        
        # Evaluate model
        loss, accuracy = self.model_manager.evaluate_model(self.test_texts, self.test_labels)
        
        print(f"Client: Evaluation completed - Loss: {loss:.4f}, Accuracy: {accuracy:.4f}")
        
        # Return evaluation metrics
        return loss, len(self.test_texts), {"eval_accuracy": accuracy}

def main():
    print("Starting Flower Federated Learning Client...")
    
    # Default server address with your specified IP and port
    default_server = "10.2.195.174:8081"
    
    # Get server address from command line or use default
    if len(sys.argv) > 1:
        server_address = sys.argv[1]
    else:
        user_input = input(f"Enter server address (press Enter for {default_server}): ").strip()
        server_address = user_input if user_input else default_server
    
    # Ensure port is included
    if ":" not in server_address:
        server_address = f"{server_address}:8081"
    
    print(f"Connecting to server at: {server_address}")
    
    # Create client instance
    client = FederatedClient()
    
    try:
        # Start client
        print("Client is ready to connect...")
        fl.client.start_numpy_client(
            server_address=server_address,
            client=client,
        )
    except KeyboardInterrupt:
        print("\nClient stopped by user.")
    except Exception as e:
        print(f"Client error: {e}")
        print("Make sure the server is running and the IP address is correct.")
        print(f"Expected server address: {default_server}")

if __name__ == "_main_":
    main()