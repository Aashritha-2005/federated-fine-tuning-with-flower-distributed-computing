import flwr as fl
import torch
from transformers import AlbertTokenizer, AlbertForSequenceClassification
from typing import Dict, List, Tuple, Optional
import socket

class FederatedStrategy(fl.server.strategy.FedAvg):
    def __init__(self):
        super().__init__(
            min_fit_clients=1,         # Change to the no.of clients you want to train 
            min_evaluate_clients=1,    # Change to the no.of clients you want to evaluate 
            min_available_clients=1,   # Change to the min no.of clients you want to connect
            evaluate_metrics_aggregation_fn=self.weighted_average,
            on_fit_config_fn=self.fit_config,
            on_evaluate_config_fn=self.evaluate_config,
        )
        # Initialize the same model as client
        print("Server: Loading ALBERT model...")
        self.model = AlbertForSequenceClassification.from_pretrained("albert-base-v2", num_labels=2)
        print("Server: Model loaded successfully")
        
    def initialize_parameters(self, client_manager) -> Optional[fl.common.Parameters]:
        """Initialize global model parameters."""
        print("Server: Initializing global model parameters...")
        try:
            # Get parameters from the ALBERT model
            parameters = [val.cpu().numpy() for _, val in self.model.state_dict().items()]
            print(f"Server: Extracted {len(parameters)} parameter arrays")
            return fl.common.ndarrays_to_parameters(parameters)
        except Exception as e:
            print(f"Server: Error initializing parameters: {e}")
            raise
    
    def fit_config(self, server_round: int) -> Dict[str, str]:
        """Return training configuration dict for each round."""
        config = {
            "server_round": str(server_round),
            "local_epochs": "1",
        }
        print(f"Server: Sending fit config for round {server_round}: {config}")
        return config
    
    def evaluate_config(self, server_round: int) -> Dict[str, str]:
        """Return evaluation configuration dict for each round."""
        config = {
            "server_round": str(server_round),
        }
        print(f"Server: Sending evaluate config for round {server_round}: {config}")
        return config
    
    def aggregate_fit(self, server_round: int, results, failures):
        """Aggregate fit results using weighted average."""
        print(f"Server: === ROUND {server_round} FIT AGGREGATION ===")
        print(f"Server: Received {len(results)} fit results, {len(failures)} failures")
        
        if failures:
            print("Server: Failures during fit:")
            for failure in failures:
                print(f"  - {failure}")
        
        if not results:
            print("Server: No fit results to aggregate!")
            return None, {}
        
        # Log client results
        for i, (client_proxy, fit_res) in enumerate(results):
            print(f"Server: Client {i+1} - Samples: {fit_res.num_examples}, Metrics: {fit_res.metrics}")
        
        # Call parent aggregation
        try:
            aggregated_parameters, aggregated_metrics = super().aggregate_fit(server_round, results, failures)
            
            if aggregated_parameters is not None:
                print(f"Server: Successfully aggregated parameters for round {server_round}")
                print(f"Server: Aggregated metrics: {aggregated_metrics}")
            else:
                print(f"Server: Failed to aggregate parameters for round {server_round}")
            
            return aggregated_parameters, aggregated_metrics
        except Exception as e:
            print(f"Server: Error during fit aggregation: {e}")
            raise
    
    def aggregate_evaluate(self, server_round: int, results, failures):
        """Aggregate evaluation results."""
        print(f"Server: === ROUND {server_round} EVALUATE AGGREGATION ===")
        print(f"Server: Received {len(results)} evaluate results, {len(failures)} failures")
        
        if failures:
            print("Server: Failures during evaluate:")
            for failure in failures:
                print(f"  - {failure}")
        
        if not results:
            print("Server: No evaluate results to aggregate!")
            return None, {}
        
        # Log client results
        for i, (client_proxy, evaluate_res) in enumerate(results):
            print(f"Server: Client {i+1} - Loss: {evaluate_res.loss:.4f}, Samples: {evaluate_res.num_examples}")
            print(f"Server: Client {i+1} - Metrics: {evaluate_res.metrics}")
        
        # Call parent aggregation
        try:
            aggregated_loss, aggregated_metrics = super().aggregate_evaluate(server_round, results, failures)
            
            if aggregated_metrics:
                print(f"Server: Round {server_round} - Final aggregated metrics: {aggregated_metrics}")
            
            return aggregated_loss, aggregated_metrics
        except Exception as e:
            print(f"Server: Error during evaluate aggregation: {e}")
            raise
    
    def weighted_average(self, metrics: List[Tuple[int, Dict[str, float]]]) -> Dict[str, float]:
        """Aggregate evaluation metrics from clients."""
        if not metrics:
            print("Server: No metrics to aggregate")
            return {}
            
        print(f"Server: Aggregating metrics from {len(metrics)} clients")
        
        total_examples = sum([num_examples for num_examples, _ in metrics])
        print(f"Server: Total examples across all clients: {total_examples}")
        
        # Weighted average of accuracies
        accuracies = []
        for num_examples, m in metrics:
            acc = m.get("eval_accuracy", 0.0)
            accuracies.append(num_examples * acc)
            print(f"Server: Client with {num_examples} examples, accuracy: {acc:.4f}")
        
        weighted_accuracy = sum(accuracies) / total_examples if total_examples > 0 else 0.0
        
        print(f"Server: Final aggregated evaluation accuracy: {weighted_accuracy:.4f}")
        return {"accuracy": weighted_accuracy}

def main():
    print("Starting Flower Federated Learning Server...")
    print("=" * 60)
    
    # Use the specified IP and port
    server_ip = "192.168.33.72"  # Make sure to replace with your server's IP address
    server_port = 8081  # Replace with your server's port
    server_address = f"{server_ip}:{server_port}"
    
    print(f"Server will run on: {server_address}")
    print("Make sure your client connects to this address!")
    print("=" * 60)
    
    # Create strategy
    try:
        print("Server: Creating federated strategy...")
        strategy = FederatedStrategy()
        print("Server: Strategy created successfully")
    except Exception as e:
        print(f"Server: Error creating strategy: {e}")
        return
    
    try:
        # Start server
        print("Server: Starting server and waiting for clients...")
        print("Server: Federated learning will begin once a client connects...")
        print("=" * 60)
        
        fl.server.start_server(
            server_address=server_address,
            config=fl.server.ServerConfig(num_rounds=3),
            strategy=strategy,
        )
        
        print("=" * 60)
        print("Server: Federated learning completed successfully!")
        
    except KeyboardInterrupt:
        print("\n" + "=" * 60)
        print("Server: Stopped by user.")
    except Exception as e:
        print("=" * 60)
        print(f"Server: Error: {e}")
        print("Server: Make sure the IP address and port are available.")
        print("Server: Check if firewall is blocking the connection.")

if __name__ == "__main__":
    main()

